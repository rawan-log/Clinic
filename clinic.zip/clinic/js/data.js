/* ==========================================================
   data.js - Mock data for the Clinic Appointment Booking System
   Front-end demo only: data lives in the browser (localStorage).
   Demo accounts:
     Patient : patient@clinic.com / patient123
     Doctor  : habiba@clinic.com  / doctor123
     Admin   : admin@clinic.com   / admin123
   ========================================================== */

const DB_KEY = "clinic_db_v2";
const SESSION_KEY = "clinic_session_v2";

const SPECIALTIES = [
  { name: "Cardiology", icon: "❤️" },
  { name: "Dermatology", icon: "🧴" },
  { name: "Pediatrics", icon: "🧸" },
  { name: "Orthopedics", icon: "🦴" },
  { name: "General Medicine", icon: "🩺" }
];

function isoDate(offsetDays) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function seedDate(offset) {
  let o = offset;
  while (new Date(isoDate(o) + "T00:00:00").getDay() === 5) o += 1;
  return isoDate(o);
}

/* days: 0 = Sunday ... 6 = Saturday */
function seedData() {
  return {
    admin: { name: "Clinic Administrator", email: "admin@clinic.com", password: "admin123" },

    doctors: [
      { id: 1, name: "Dr. Habiba Hany", specialty: "Cardiology", email: "habiba@clinic.com", password: "doctor123", experience: 12, fee: 400, days: [0, 1, 2, 3, 4, 6], from: "09:00", to: "14:00", bio: "Consultant cardiologist focused on preventive cardiology, hypertension and heart failure management." },
      { id: 2, name: "Dr. Salma Tamer", specialty: "Dermatology", email: "salma@clinic.com", password: "doctor123", experience: 9, fee: 300, days: [0, 1, 2, 3, 4, 6], from: "10:00", to: "15:00", bio: "Treats acne, eczema, hair loss and common skin conditions for adults and teenagers." },
      { id: 3, name: "Dr. Menna Refaat", specialty: "Pediatrics", email: "menna@clinic.com", password: "doctor123", experience: 10, fee: 250, days: [0, 1, 2, 3, 4, 6], from: "09:00", to: "13:00", bio: "Pediatrician caring for newborns, children and teens, including vaccinations and growth follow-up." },
      { id: 4, name: "Dr. Youssef Awad", specialty: "Orthopedics", email: "youssef.awad@clinic.com", password: "doctor123", experience: 15, fee: 450, days: [0, 1, 2, 3, 4, 6], from: "11:00", to: "17:00", bio: "Orthopedic surgeon specialising in sports injuries, joint pain and fracture follow-up." },
      { id: 5, name: "Dr. Youssef Hussein", specialty: "General Medicine", email: "youssef.hussein@clinic.com", password: "doctor123", experience: 8, fee: 200, days: [0, 1, 2, 3, 4, 6], from: "09:00", to: "16:00", bio: "Family physician for check-ups, chronic disease follow-up and first-line medical advice." }
    ],

    patients: [
      { id: 1, name: "Mohamed Adel", email: "patient@clinic.com", password: "patient123", phone: "01012345678" },
      { id: 2, name: "Heba Samy", email: "heba@mail.com", password: "patient123", phone: "01123456789" },
      { id: 3, name: "Karim Tarek", email: "karim@mail.com", password: "patient123", phone: "01234567890" }
    ],

    appointments: [
      { id: 1, patientId: 1, doctorId: 1, date: seedDate(0), time: "10:00", reason: "Blood pressure follow-up", status: "Confirmed" },
      { id: 2, patientId: 2, doctorId: 1, date: seedDate(0), time: "11:30", reason: "Chest discomfort", status: "Confirmed" },
      { id: 3, patientId: 3, doctorId: 1, date: seedDate(0), time: "12:30", reason: "Routine check-up", status: "Confirmed" },
      { id: 4, patientId: 1, doctorId: 2, date: seedDate(2), time: "11:00", reason: "Skin rash", status: "Confirmed" },
      { id: 5, patientId: 2, doctorId: 3, date: seedDate(1), time: "09:30", reason: "Child vaccination", status: "Confirmed" },
      { id: 6, patientId: 1, doctorId: 5, date: seedDate(-9), time: "10:00", reason: "General check-up", status: "Confirmed" },
      { id: 7, patientId: 1, doctorId: 3, date: seedDate(-4), time: "09:00", reason: "Seasonal flu", status: "Cancelled" },
      { id: 8, patientId: 3, doctorId: 4, date: seedDate(3), time: "12:00", reason: "Knee pain", status: "Confirmed" },
      { id: 9, patientId: 2, doctorId: 1, date: seedDate(1), time: "09:00", reason: "ECG review", status: "Confirmed" }
    ]
  };
}

function loadDB() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) { /* fall through to seed */ }
  const fresh = seedData();
  saveDB(fresh);
  return fresh;
}

function saveDB(db) {
  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) { /* storage unavailable */ }
}
