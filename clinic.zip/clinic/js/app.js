/* ==========================================================
   app.js - Shared logic for all pages
   (session, navigation, booking rules, small UI helpers)
   ========================================================== */

let DB = loadDB();
function persist() { saveDB(DB); }

/* ---------- Generic helpers ---------- */
function esc(str) {
  return String(str == null ? "" : str).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}
function qs(name) { return new URLSearchParams(location.search).get(name); }
function nextId(list) { return list.reduce(function (m, x) { return Math.max(m, x.id); }, 0) + 1; }

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function parseISO(s) { const p = s.split("-").map(Number); return new Date(p[0], p[1] - 1, p[2]); }
function todayISO() { return isoDate(0); }
function fmtDate(s) { const d = parseISO(s); return DAY_NAMES[d.getDay()] + ", " + d.getDate() + " " + MONTH_NAMES[d.getMonth()] + " " + d.getFullYear(); }
function fmtTime(t) {
  const p = t.split(":").map(Number);
  const h = p[0] % 12 === 0 ? 12 : p[0] % 12;
  return h + ":" + String(p[1]).padStart(2, "0") + " " + (p[0] >= 12 ? "PM" : "AM");
}
function initials(name) { return name.replace(/^Dr\.\s*/, "").split(" ").slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase(); }

function genSlots(from, to) {
  const out = [];
  let m = Number(from.split(":")[0]) * 60 + Number(from.split(":")[1]);
  const end = Number(to.split(":")[0]) * 60 + Number(to.split(":")[1]);
  while (m + 30 <= end) {
    out.push(String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0"));
    m += 30;
  }
  return out;
}

/* ---------- Lookups ---------- */
function getDoctor(id) { return DB.doctors.find(function (d) { return d.id === Number(id); }); }
function getPatient(id) { return DB.patients.find(function (p) { return p.id === Number(id); }); }
function doctorSlots(d) { return genSlots(d.from, d.to); }
function doctorWorksOn(d, dateStr) { return d.days.indexOf(parseISO(dateStr).getDay()) !== -1; }
function daysLabel(d) { return d.days.slice().sort().map(function (n) { return DAY_NAMES[n]; }).join(", "); }

/* ---------- Appointment status & rules ---------- */
function apptDateTime(a) {
  const t = a.time.split(":").map(Number);
  const d = parseISO(a.date);
  d.setHours(t[0], t[1], 0, 0);
  return d;
}
/* A confirmed appointment whose time has passed is shown as Completed */
function statusOf(a) {
  if (a.status === "Cancelled") return "Cancelled";
  return apptDateTime(a) < new Date() ? "Completed" : "Confirmed";
}
function byDateTime(a, b) { return apptDateTime(a) - apptDateTime(b); }
function isSlotPast(date, time) { return apptDateTime({ date: date, time: time }) < new Date(); }

function bookedTimes(doctorId, date, ignoreId) {
  return DB.appointments
    .filter(function (a) { return a.doctorId === Number(doctorId) && a.date === date && a.status !== "Cancelled" && a.id !== ignoreId; })
    .map(function (a) { return a.time; });
}

/* Core rule from the project scenario: check conflicts before saving */
function checkBooking(o) {
  const doctor = getDoctor(o.doctorId);
  if (!doctor) return { ok: false, error: "Please choose a doctor." };
  if (!o.date || !o.time) return { ok: false, error: "Please choose a date and a time slot." };
  if (!doctorWorksOn(doctor, o.date)) return { ok: false, error: doctor.name + " does not work on this day." };
  if (isSlotPast(o.date, o.time)) return { ok: false, error: "This time has already passed. Please choose a later slot." };
  if (bookedTimes(doctor.id, o.date, o.ignoreId).indexOf(o.time) !== -1) {
    return { ok: false, error: "This slot is already booked. Please choose another time." };
  }
  const clash = DB.appointments.some(function (a) {
    return a.patientId === o.patientId && a.date === o.date && a.time === o.time && a.status !== "Cancelled" && a.id !== o.ignoreId;
  });
  if (clash) return { ok: false, error: "You already have another appointment at this time." };
  return { ok: true };
}

function createAppointment(o) {
  const a = { id: nextId(DB.appointments), patientId: o.patientId, doctorId: Number(o.doctorId), date: o.date, time: o.time, reason: o.reason || "", status: "Confirmed" };
  DB.appointments.push(a);
  persist();
  return a;
}
function rescheduleAppointment(id, date, time, reason) {
  const a = DB.appointments.find(function (x) { return x.id === id; });
  a.date = date; a.time = time; a.reason = reason;
  persist();
  return a;
}
function cancelAppointment(id) {
  const a = DB.appointments.find(function (x) { return x.id === id; });
  if (a) { a.status = "Cancelled"; persist(); }
}

function nextAvailable(doctor) {
  const slots = doctorSlots(doctor);
  for (let i = 0; i < 30; i++) {
    const date = isoDate(i);
    if (!doctorWorksOn(doctor, date)) continue;
    const taken = bookedTimes(doctor.id, date);
    const free = slots.filter(function (t) { return taken.indexOf(t) === -1 && !isSlotPast(date, t); });
    if (free.length) return { date: date, time: free[0] };
  }
  return null;
}
function freeSlotCount(doctor, date) {
  if (!doctorWorksOn(doctor, date)) return 0;
  const taken = bookedTimes(doctor.id, date);
  return doctorSlots(doctor).filter(function (t) { return taken.indexOf(t) === -1 && !isSlotPast(date, t); }).length;
}

/* ---------- Session ---------- */
function getSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY)); } catch (e) { return null; }
}
function setSession(s) { try { localStorage.setItem(SESSION_KEY, JSON.stringify(s)); } catch (e) { /* ignore */ } }
function homeFor(role) {
  return { patient: "patient-dashboard.html", doctor: "doctor-dashboard.html", admin: "admin-dashboard.html" }[role];
}
function login(role, email, password) {
  email = email.trim().toLowerCase();
  if (role === "admin") {
    if (email === DB.admin.email && password === DB.admin.password) { setSession({ role: "admin", id: 0 }); return { ok: true }; }
  } else {
    const list = role === "patient" ? DB.patients : DB.doctors;
    const u = list.find(function (x) { return x.email.toLowerCase() === email && x.password === password; });
    if (u) { setSession({ role: role, id: u.id }); return { ok: true }; }
  }
  return { ok: false, error: "Incorrect email or password for the selected role." };
}
function registerPatient(o) {
  const email = o.email.trim().toLowerCase();
  const exists = DB.patients.concat(DB.doctors).some(function (x) { return x.email.toLowerCase() === email; }) || email === DB.admin.email;
  if (exists) return { ok: false, error: "An account with this email already exists." };
  const p = { id: nextId(DB.patients), name: o.name.trim(), email: email, password: o.password, phone: o.phone.trim() };
  DB.patients.push(p);
  persist();
  setSession({ role: "patient", id: p.id });
  return { ok: true };
}
function logout() {
  try { localStorage.removeItem(SESSION_KEY); } catch (e) { /* ignore */ }
  location.href = "index.html";
}
function requireRole(role) {
  const s = getSession();
  if (!s || s.role !== role) { location.replace("index.html"); return null; }
  if (role === "patient" && !getPatient(s.id)) { logout(); return null; }
  if (role === "doctor" && !getDoctor(s.id)) { logout(); return null; }
  return s;
}

/* ---------- Navigation bar ---------- */
function renderNav(activeKey) {
  const s = getSession();
  const el = document.getElementById("nav");
  if (!el || !s) return;
  const links = {
    patient: [["dashboard", "Dashboard", "patient-dashboard.html"], ["doctors", "Doctors", "doctors.html"], ["appointments", "My Appointments", "my-appointments.html"]],
    doctor: [["dashboard", "My Schedule", "doctor-dashboard.html"]],
    admin: [["dashboard", "Admin Panel", "admin-dashboard.html"]]
  }[s.role];
  let name = "Administrator";
  if (s.role === "patient") name = getPatient(s.id).name;
  if (s.role === "doctor") name = getDoctor(s.id).name;
  const roleLabel = { patient: "Patient", doctor: "Doctor", admin: "Admin" }[s.role];
  el.innerHTML =
    '<header class="navbar"><div class="navbar-inner">' +
    '<a class="brand" href="' + homeFor(s.role) + '"><span class="brand-logo">✚</span> MediCare Clinic</a>' +
    '<button class="nav-toggle" id="navToggle" aria-label="Toggle menu">☰</button>' +
    '<nav class="nav-links" id="navLinks">' +
    links.map(function (l) { return '<a href="' + l[2] + '" class="' + (l[0] === activeKey ? "active" : "") + '">' + l[1] + "</a>"; }).join("") +
    '<span class="nav-user"><span class="nav-user-name">' + esc(name) + '</span><span class="badge badge-role">' + roleLabel + "</span></span>" +
    '<button class="btn btn-sm btn-ghost" id="logoutBtn">Logout</button>' +
    "</nav></div></header>";
  document.getElementById("logoutBtn").addEventListener("click", logout);
  document.getElementById("navToggle").addEventListener("click", function () {
    document.getElementById("navLinks").classList.toggle("open");
  });
}

/* ---------- Toasts & dialogs ---------- */
function toast(message, type) {
  let box = document.getElementById("toastBox");
  if (!box) { box = document.createElement("div"); box.id = "toastBox"; box.className = "toast-box"; document.body.appendChild(box); }
  const t = document.createElement("div");
  t.className = "toast toast-" + (type || "info");
  t.textContent = message;
  box.appendChild(t);
  setTimeout(function () { t.classList.add("hide"); setTimeout(function () { t.remove(); }, 300); }, 3200);
}

function confirmDialog(o) {
  return new Promise(function (resolve) {
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true"><h3>' + esc(o.title) + "</h3><p>" + esc(o.message) + "</p>" +
      '<div class="modal-actions"><button class="btn btn-outline" data-r="0">Keep it</button>' +
      '<button class="btn ' + (o.danger ? "btn-danger" : "btn-primary") + '" data-r="1">' + esc(o.confirmText || "Confirm") + "</button></div></div>";
    document.body.appendChild(overlay);
    overlay.addEventListener("click", function (e) {
      const b = e.target.closest("[data-r]");
      if (b || e.target === overlay) { overlay.remove(); resolve(!!b && b.dataset.r === "1"); }
    });
  });
}

/* ---------- Shared UI snippets ---------- */
function statusBadge(status) {
  const cls = { Confirmed: "badge-success", Completed: "badge-info", Cancelled: "badge-danger" }[status] || "badge-info";
  return '<span class="badge ' + cls + '">' + status + "</span>";
}
function avatarHTML(d, big) {
  const colors = ["#0e7c86", "#2f6fd6", "#8a4fd0", "#d9822b", "#1f9d62", "#c2415b", "#4a6572", "#b8860b"];
  return '<div class="avatar' + (big ? " avatar-lg" : "") + '" style="background:' + colors[(d.id - 1) % colors.length] + '">' + esc(initials(d.name)) + "</div>";
}
function apptActionsHTML(a) {
  if (statusOf(a) !== "Confirmed") return '<span class="muted">—</span>';
  return '<a class="btn btn-sm btn-outline" href="booking.html?reschedule=' + a.id + '">Reschedule</a> ' +
    '<button class="btn btn-sm btn-danger-outline" data-cancel="' + a.id + '">Cancel</button>';
}
function wireCancel(container, onDone) {
  container.addEventListener("click", async function (e) {
    const b = e.target.closest("[data-cancel]");
    if (!b) return;
    const id = Number(b.dataset.cancel);
    const a = DB.appointments.find(function (x) { return x.id === id; });
    const d = getDoctor(a.doctorId);
    const ok = await confirmDialog({
      title: "Cancel this appointment?",
      message: "Your appointment with " + d.name + " on " + fmtDate(a.date) + " at " + fmtTime(a.time) + " will be cancelled and the slot will be released.",
      confirmText: "Yes, cancel it",
      danger: true
    });
    if (ok) { cancelAppointment(id); toast("Appointment cancelled.", "success"); onDone(); }
  });
}
