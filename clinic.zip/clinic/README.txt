MediCare Clinic - Front-end (Appointment Booking)
Open index.html in any browser. No server needed.

Demo accounts
  Patient : patient@clinic.com / patient123
  Doctor  : habiba@clinic.com  / doctor123
  Admin   : admin@clinic.com   / admin123

Pages: index (login/register), patient-dashboard, doctors, doctor-profile,
booking (also used for reschedule), my-appointments, doctor-dashboard, admin-dashboard.
Data is mock and stored in the browser (localStorage). To reset: clear site data.
